		</main>

		<footer class="text-muted">
			<div class="container text-center">
				<p>2021 @ PT Majoo Teknologi Indonesia</p>
			</div>
		</footer>
		<script src="<?= base_url();?>assets/js/bootstrap.js"></script>
	</body>

</html>
