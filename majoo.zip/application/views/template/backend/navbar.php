<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">POS MINI</a>
  <a class="nav-link text-white" href="<?= base_url();?>">beranda</a>
  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <a class="nav-link" href="<?= site_url('keluar');?>">keluar</a>
    </li>
  </ul>
</nav>